package DataTypes;


public class ConstStrings {

	public static int EF = 0;
	public static int AF1 = 1;
	public static int AF2 = 2;
	public static int AF3 = 3;
	public static int AF4 = 4;
	public static int BestEffort = 5;
	public static int PHB_EF = 0;
	public static int PHB_AF = 1;
	public static int PHB_BE = 2;
	public static int DSCP11 = 10;
	public static int DSCP12 = 12;
	public static int DSCP13 = 14;
	public static int DSCP21 = 18;
	public static int DSCP22 = 20;
	public static int DSCP23 = 22;
	public static int DSCP31 = 26;
	public static int DSCP32 = 28;
	public static int DSCP33 = 30;
	public static int DSCP41 = 34;
	public static int DSCP42 = 36;
	public static int DSCP43 = 38;
	public static int DSCP_BE = 0;
	public static int DSCP_EF = 46;
}
